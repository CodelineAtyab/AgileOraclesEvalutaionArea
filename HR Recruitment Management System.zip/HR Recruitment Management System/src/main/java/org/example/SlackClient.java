package org.example;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

@Component
public class SlackClient {

    private final String webhookUrl;
    private final HttpClient http = HttpClient.newHttpClient();

    // Injected from application.yml, which reads it from the environment.
    // The URL never appears in this file.
    public SlackClient(@Value("${slack.webhook}") String webhookUrl) {
        this.webhookUrl = webhookUrl;
    }

    public void post(String message) throws Exception {
        String json = "{\"text\":\"" + escape(message) + "\"}";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(webhookUrl))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpResponse<String> response =
                http.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            throw new RuntimeException("Slack rejected the message: "
                    + response.statusCode() + " " + response.body());
        }
    }

    private String escape(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n");
    }
}
