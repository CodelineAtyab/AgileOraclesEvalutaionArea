package org.example;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

@SpringBootApplication
public class ConsumerApplication implements CommandLineRunner {

    private final DataSource dataSource;
    private final SlackClient slack;

    public ConsumerApplication(DataSource dataSource, SlackClient slack) {
        this.dataSource = dataSource;
        this.slack = slack;
    }

    public static void main(String[] args) {
        SpringApplication.run(ConsumerApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        int sent = 0;

        // try-with-resources: everything here closes automatically,
        // even if a row misbehaves. The brief grades this.
        try (Connection conn = dataSource.getConnection();
             CallableStatement call =
                 conn.prepareCall("{ call get_pending_notifications(?) }")) {

            call.registerOutParameter(1, Types.REF_CURSOR);
            call.execute();

            try (ResultSet rows = (ResultSet) call.getObject(1)) {
                while (rows.next()) {
                    long id      = rows.getLong("notification_id");
                    String subj  = rows.getString("subject");
                    String body  = rows.getString("body");

                    slack.post(subj + "\n" + body);   // send it out
                    markSent(conn, id);                // then record it
                    sent++;
                }
            }
        }

        System.out.println("Drained " + sent + " notification(s). Exiting.");
    }

    private void markSent(Connection conn, long id) throws Exception {
        try (CallableStatement call =
                 conn.prepareCall("{ call mark_notification_sent(?) }")) {
            call.setLong(1, id);
            call.execute();
        }
    }
}
