CREATE TABLE vacant_jobs (
    job_id          NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    job_title       VARCHAR2(100) NOT NULL,
    description     VARCHAR2(2000) NOT NULL,
    posted_at       TIMESTAMP DEFAULT SYSTIMESTAMP NOT NULL,
    expires_at      TIMESTAMP NOT NULL,
    is_active       CHAR(1) DEFAULT 'Y' NOT NULL 
                    CHECK (is_active IN ('Y', 'N'))
);

ALTER TABLE vacant_jobs
    ADD CONSTRAINT chk_vacant_jobs_active CHECK (is_active IN ('Y','N'));

ALTER TABLE vacant_jobs
    ADD CONSTRAINT chk_vacant_jobs_dates CHECK (expires_at > posted_at);
    
    
CREATE TABLE jobs_posting_archive (
    job_id          NUMBER          PRIMARY KEY,
    job_title       VARCHAR2(200)   NOT NULL,
    description     VARCHAR2(4000)  NOT NULL,
    posted_at       TIMESTAMP       NOT NULL,
    expires_at      TIMESTAMP       NOT NULL,
    archived_at     TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL
);


CREATE TABLE job_applications (
    application_id  NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    job_id          NUMBER,
    applicant_name  VARCHAR2(200)   NOT NULL,
    applied_at      TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT fk_job_applications_job
        FOREIGN KEY (job_id) REFERENCES vacant_jobs (job_id)
        ON DELETE SET NULL
);


CREATE TABLE notificationshr (
    notification_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    job_id          NUMBER,
    subject         VARCHAR2(200)   NOT NULL,
    body            VARCHAR2(4000)  NOT NULL,
    sent_flag       CHAR(1)         DEFAULT 'N' NOT NULL,
    created_at      TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT chk_notifications_sent CHECK (sent_flag IN ('Y','N')),
    CONSTRAINT fk_notifications_job
        FOREIGN KEY (job_id) REFERENCES vacant_jobs (job_id)
        ON DELETE SET NULL
);

CREATE OR REPLACE TRIGGER trg_vacant_jobs_after_insert
AFTER INSERT ON vacant_jobs
FOR EACH ROW
BEGIN
    register_notificationhr(:NEW.job_id);
END trg_vacant_jobs_after_insert;
/

INSERT INTO vacant_jobs (job_title, description, posted_at, expires_at, is_active)
VALUES ('Test Trigger Job', 'Testing the automatic notification.',
        SYSTIMESTAMP, SYSTIMESTAMP + INTERVAL '5' DAY, 'Y');