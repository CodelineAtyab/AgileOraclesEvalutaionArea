--STEP 08: PROCEDURE (jobs archive)
SELECT * FROM jobs_posting_archive;

CREATE OR REPLACE PROCEDURE archive_jobs
AS
BEGIN
    INSERT INTO jobs_posting_archive
    (
        job_id,
        job_title,
        description,
        posted_at,
        expires_at
    )
    SELECT
        job_id,
        job_title,
        description,
        posted_at,
        expires_at
    FROM vacant_jobs
    WHERE is_active = 'N';

    COMMIT;
END;
/

EXEC archive_jobs;


SELECT * FROM jobs_posting_archive
ORDER BY job_id DESC;

-- STEP 09: PROCEDURE (Purge inactive jobs)
CREATE OR REPLACE PROCEDURE purge_inactive_jobs
AS
BEGIN
    DELETE FROM vacant_jobs
    WHERE is_active = 'N';

    COMMIT;
END;
/

EXEC purge_inactive_jobs;

SELECT * FROM vacant_jobs WHERE is_active = 'N';

-- STEP 10: PROCEDURE WITH IMPLICIT CURSOR (Sweep descriptions)
CREATE OR REPLACE PROCEDURE sweep_descriptions
AS
BEGIN
-- Implicit cursor loop for active jobs
    FOR rec IN (
        SELECT job_id, description
        FROM vacant_jobs
        WHERE is_active = 'Y'
    )
    LOOP
        
        UPDATE vacant_jobs
        SET description = my_lowercase(description)
        WHERE job_id = rec.job_id;
    END LOOP;

    COMMIT;
END;
/
SET SERVEROUTPUT ON;
EXEC sweep_descriptions;



INSERT INTO vacant_jobs
(job_title, description, posted_at, expires_at, is_active)
VALUES
(
    'Cursor NEW Test',
    'THIS DESCRIPTION CURSOR',
    SYSTIMESTAMP,
    SYSTIMESTAMP + INTERVAL '5' DAY,
    'Y'
);

COMMIT;

SELECT job_id,
       job_title,
       description,
       is_active
FROM vacant_jobs;


SELECT * FROM job_applications;

SELECT constraint_name,
       constraint_type
FROM user_constraints
WHERE table_name = 'JOB_APPLICATIONS';

SELECT column_name,
       nullable
FROM user_tab_columns
WHERE table_name = 'JOB_APPLICATIONS';


SELECT * FROM job_applications
WHERE job_id IS NULL;

COMMIT;

-- STEP 12: PROCEDURE WITH IMPLICIT CURSOR
CREATE OR REPLACE PROCEDURE generate_daily_digest
AS
BEGIN
    FOR rec IN
    (
        SELECT v.job_id,
               v.description,
               COUNT(a.application_id) AS applicant_count
        FROM vacant_jobs v
        JOIN job_applications a
             ON v.job_id = a.job_id
        GROUP BY v.job_id, v.description
    )
    LOOP

        INSERT INTO notificationshr
        (
            job_id,
            subject,
            body,
            sent_flag,
            created_at
        )
        VALUES
        (
            rec.job_id,
            'Daily Application Digest',
            'Job ID: ' || rec.job_id ||
            ' | Description: ' || rec.description ||
            ' | Applications: ' || rec.applicant_count,
            'N',
            SYSTIMESTAMP
        );

    END LOOP;

    COMMIT;
END;
/

EXEC generate_daily_digest;

SELECT * FROM notificationshr
ORDER BY notification_id DESC;


-- STEP 13: PROCEDURE WITH EXPLICIT REFCURSOR
CREATE OR REPLACE PROCEDURE get_pending_notifications
(
    p_cursor OUT SYS_REFCURSOR
)
AS
BEGIN
    OPEN p_cursor FOR
    SELECT notification_id,
           job_id,
           subject,
           body
    FROM notificationshr
    WHERE sent_flag = 'N'
    ORDER BY notification_id;
END;
/

VARIABLE rc REFCURSOR;
EXEC get_pending_notifications(:rc);

-- 1. Job to expire jobs every 1 minute
BEGIN
    DBMS_SCHEDULER.CREATE_JOB (
    job_name        => 'job_expire_jobs',
    job_type        => 'STORED_PROCEDURE',
    job_action      => 'expire_jobs',
    start_date      => SYSTIMESTAMP,
    repeat_interval => 'FREQ=MINUTELY; INTERVAL=1',
    enabled         => TRUE
  );
-- 2. Job to archive inactive jobs every 1 minute
  DBMS_SCHEDULER.CREATE_JOB (
    job_name        => 'job_archive_jobs',
    job_type        => 'STORED_PROCEDURE',
    job_action      => 'archive_jobs',
    start_date      => SYSTIMESTAMP,
    repeat_interval => 'FREQ=MINUTELY; INTERVAL=1',
    enabled         => TRUE
  );
-- 3. Job to purge inactive jobs every 1 minute
  DBMS_SCHEDULER.CREATE_JOB (
    job_name        => 'job_purge_inactive_jobs',
    job_type        => 'STORED_PROCEDURE',
    job_action      => 'purge_inactive_jobs',
    start_date      => SYSTIMESTAMP,
    repeat_interval => 'FREQ=MINUTELY; INTERVAL=1',
    enabled         => TRUE
  );
-- 4. Job to sweep and lowercase descriptions every 5 minutes
  DBMS_SCHEDULER.CREATE_JOB (
    job_name        => 'job_sweep_descriptions',
    job_type        => 'STORED_PROCEDURE',
    job_action      => 'sweep_descriptions',
    start_date      => SYSTIMESTAMP,
    repeat_interval => 'FREQ=MINUTELY; INTERVAL=5',
    enabled         => TRUE
  );
-- 5. Job to generate daily digest once a day at 8 AM
  DBMS_SCHEDULER.CREATE_JOB (
    job_name        => 'job_generate_daily_digest',
    job_type        => 'STORED_PROCEDURE',
    job_action      => 'generate_daily_digest',
    start_date      => SYSTIMESTAMP,
    repeat_interval => 'FREQ=DAILY; BYHOUR=8',
    enabled         => TRUE
  );
END;
/
-- View all currently active scheduled jobs
SELECT job_name, enabled, state, repeat_interval 
FROM user_scheduler_jobs;

-- Check live vacant jobs status
SELECT job_id, job_title, is_active, expires_at
FROM   vacant_jobs
ORDER BY job_id;

-- Check archived jobs data
SELECT job_id, job_title, archived_at
FROM   jobs_posting_archive
ORDER BY archived_at DESC;



