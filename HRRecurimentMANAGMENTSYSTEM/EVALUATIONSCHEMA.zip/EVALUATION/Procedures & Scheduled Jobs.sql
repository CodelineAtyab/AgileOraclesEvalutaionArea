-- ARTEFACT 4 & 7: Procedures & Scheduled Jobs
CREATE OR REPLACE PROCEDURE expire_jobs
AS
BEGIN
    UPDATE vacant_jobs
    SET is_active = 'N'
    WHERE expires_at < SYSTIMESTAMP
      AND is_active = 'Y';

    COMMIT;
END;
/

-- TESTING STEP 07
INSERT INTO vacant_jobs(job_title, description, posted_at, expires_at, is_active)
VALUES('Expire Test', 'testing expire procedure', SYSTIMESTAMP - INTERVAL '10' DAY, SYSTIMESTAMP - INTERVAL '1' DAY, 'Y');

COMMIT;

-- Execute the procedure manually to test the expiration
EXEC expire_jobs;


SELECT job_id, job_title, is_active, posted_at, expires_at
FROM vacant_jobs
ORDER BY job_id DESC;


SELECT job_id, job_title, is_active, expires_at
FROM vacant_jobs
WHERE is_active = 'N';


-- TEST JOB WILL EXPIRE AFTER ONE MINUTE
INSERT INTO vacant_jobs (job_title, description, posted_at, expires_at, is_active)
VALUES (
    'Quick Expire Test', 
    'this job will expire in one minute for testing purposes.', 
    SYSTIMESTAMP, 
    SYSTIMESTAMP + INTERVAL '1' MINUTE, 
    'Y'
);

COMMIT;




