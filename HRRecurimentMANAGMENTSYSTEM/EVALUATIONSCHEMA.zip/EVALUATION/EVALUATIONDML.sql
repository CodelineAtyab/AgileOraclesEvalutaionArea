INSERT INTO vacant_jobs (job_title, description, posted_at, expires_at, is_active)
VALUES ('Backend Engineer',
        'Build and maintain server-side services in Java and PL/SQL.',
        SYSTIMESTAMP - INTERVAL '1' DAY,
        SYSTIMESTAMP + INTERVAL '2' MINUTE,
        'Y');
 
INSERT INTO vacant_jobs (job_title, description, posted_at, expires_at, is_active)
VALUES ('QA Analyst',
        'Design and run test plans for the recruitment platform.',
        SYSTIMESTAMP - INTERVAL '3' DAY,
        SYSTIMESTAMP + INTERVAL '2' MINUTE,
        'Y');
 
INSERT INTO vacant_jobs (job_title, description, posted_at, expires_at, is_active)
VALUES ('DevOps Engineer',
        'Own CI/CD pipelines and cloud infrastructure.',
        SYSTIMESTAMP - INTERVAL '2' HOUR,
        SYSTIMESTAMP + INTERVAL '1' MINUTE,
        'Y');
 
INSERT INTO vacant_jobs (job_title, description, posted_at, expires_at, is_active)
VALUES ('Frontend Developer',
        'THIS DESCRIPTION IS SHOUTING IN ALL CAPS ON PURPOSE.',
        SYSTIMESTAMP,
        SYSTIMESTAMP + INTERVAL '7' DAY,
        'Y');
 
INSERT INTO vacant_jobs (job_title, description, posted_at, expires_at, is_active)
VALUES ('Data Analyst',
        'Turn raw hiring data into dashboards leadership can use.',
        SYSTIMESTAMP,
        SYSTIMESTAMP + INTERVAL '10' DAY,
        'Y');
 
COMMIT;

SELECT * FROM vacant_jobs;

INSERT INTO job_applications (job_id, applicant_name, applied_at)
SELECT job_id, 'Amina Al-Balushi', SYSTIMESTAMP
FROM vacant_jobs WHERE job_title = 'Backend Engineer';
 
INSERT INTO job_applications (job_id, applicant_name, applied_at)
SELECT job_id, 'Yousef Al-Hinai', SYSTIMESTAMP
FROM vacant_jobs WHERE job_title = 'DevOps Engineer';
 
INSERT INTO job_applications (job_id, applicant_name, applied_at)
SELECT job_id, 'Fatma Al-Riyami', SYSTIMESTAMP
FROM vacant_jobs WHERE job_title = 'Backend Engineer';
 
INSERT INTO job_applications (job_id, applicant_name, applied_at)
SELECT job_id, 'Salim Al-Kindi', SYSTIMESTAMP
FROM vacant_jobs WHERE job_title = 'QA Analyst';
 
INSERT INTO job_applications (job_id, applicant_name, applied_at)
SELECT job_id, 'Mariam Al-Farsi', SYSTIMESTAMP
FROM vacant_jobs WHERE job_title = 'Data Analyst';
 
COMMIT;

SELECT * FROM job_applications;

SELECT SYSTIMESTAMP AS now_time,
       SYSTIMESTAMP + INTERVAL '2' MINUTE AS after_2_min,
       SYSTIMESTAMP - INTERVAL '1' DAY AS yesterday
FROM dual;