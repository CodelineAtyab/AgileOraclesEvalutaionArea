-- ARTEFACT 4 & 5 & 6: Triggers, Procedures, Functions & Implementation Flow

-- STEP 03: PROCEDURE (Register notification for a new vacancy)
CREATE OR REPLACE PROCEDURE register_notificationhr (

    p_job_id      IN vacant_jobs.job_id%TYPE,
    p_job_title   IN vacant_jobs.job_title%TYPE,
    p_description IN vacant_jobs.description%TYPE
)
AS
    v_subject     notificationshr.subject%TYPE;
    v_body        notificationshr.body%TYPE;
BEGIN
    v_subject := 'New vacancy posted: ' || p_job_title;
    v_body    := 'A new job posting (ID ' || p_job_id || ') has gone live: '
                 || p_job_title || '. Description: ' || p_description;

    INSERT INTO notificationshr (job_id, subject, body, sent_flag, created_at)
    VALUES (p_job_id, v_subject, v_body, 'N', SYSTIMESTAMP);
END register_notificationhr;
/

-- Step 02 Trigger (Fires after a human inserts a new vacancy)
CREATE OR REPLACE TRIGGER trg_vacant_jobs_after_insert
AFTER INSERT ON vacant_jobs
FOR EACH ROW
BEGIN
    register_notificationhr(:NEW.job_id, :NEW.job_title, :NEW.description);
END trg_vacant_jobs_after_insert;
/

INSERT INTO vacant_jobs (job_title, description, posted_at, expires_at, is_active)
VALUES ('Test Trigger Job 4', 'Second attempt after the fix.',
        SYSTIMESTAMP, SYSTIMESTAMP + INTERVAL '5' DAY, 'Y');

COMMIT;

SELECT * FROM notificationshr ORDER BY notification_id DESC;


-- STEP 06: FUNCTION (My own lower-casing routine, reused by trigger and sweep)
CREATE OR REPLACE FUNCTION my_lowercase (p_text VARCHAR2)
RETURN VARCHAR2
IS
BEGIN
    RETURN LOWER(p_text);
END;
/

-- Step 05 Trigger (Fires before a description update to lowercase it automatically)
CREATE OR REPLACE TRIGGER trg_description_lowercase
BEFORE UPDATE OF description
ON vacant_jobs
FOR EACH ROW
BEGIN
    :NEW.description := my_lowercase(:NEW.description);
END;
/
-- UPDATE JOB DESCRIPTION IN CAPITAL LETTERS
UPDATE vacant_jobs SET description ='THIS IS A DESCRIPTION WRITTEN IN CAPITAL LETTERS'
WHERE job_id = 12;

COMMIT;

-- VIEW THE UPDATED JOB DESCRIPTION TO INSURE IT BECOME LOWER CASE
SELECT job_id, description
FROM vacant_jobs
WHERE job_id = 12;